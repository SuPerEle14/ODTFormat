# -*- coding: utf-8 -*-

from . import models

from odoo import api, SUPERUSER_ID


def _configure_paperformat_bottom_margins(cr, registry):
    env = api.Environment(cr, SUPERUSER_ID, {})
    paperformat_xml_ids = [
        'base.paperformat_batch_deposit',
        'base.paperformat_euro',
        'base.paperformat_us',
        'event.paperformat_euro_lowmargin',
        'hr_holidays.paperformat_hrsummary',
        'itis_business_requirements_extended.paperformat_business_requirement',
        'l10n_de.paperformat_euro_din']
    for paperformat_xml_id in paperformat_xml_ids:
        pf_module = paperformat_xml_id.split('.')[0]
        pf_name = paperformat_xml_id.split('.')[1]
        paperformat = env['ir.model.data'].search([('module', '=', pf_module), ('name', '=', pf_name)])
        if not paperformat:
            continue
        paper_format = env.ref(paperformat_xml_id)
        paper_format.margin_bottom = 40
