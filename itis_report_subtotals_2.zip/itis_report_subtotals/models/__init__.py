# -*- coding: utf-8 -*-
# Part of IT IS AG. See LICENSE file for full copyright and licensing details.


from . import ir_actions_report
from . import mail_template
from . import res_config_settings
