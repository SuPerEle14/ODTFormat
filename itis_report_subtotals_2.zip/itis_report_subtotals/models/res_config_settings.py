# -*- coding: utf-8 -*-
# Part of IT IS AG. See LICENSE file for full copyright and licensing details.

import logging
from odoo import api, fields, models, _

_logger = logging.getLogger(__name__)


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    pdftohtml_bin_location = fields.Char('PDFTOHTML Binary Location')
    show_header_total_previous_page = fields.Boolean(
        'Header page subtotal - previous page', default=False, help="Header total will be same as total on previous page")

    @api.model
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        IrConfigP = self.env['ir.config_parameter'].sudo()
        res['pdftohtml_bin_location'] = IrConfigP.get_param(
            'itis_report_subtotals.pdftohtml_bin_location', default='/usr/bin/pdftohtml')
        res['show_header_total_previous_page'] = IrConfigP.get_param(
            'itis_report_subtotals.show_header_total_previous_page', default=False)
        return res

    @api.model
    def set_values(self):
        IrConfigP = self.env['ir.config_parameter'].sudo()
        IrConfigP.set_param('itis_report_subtotals.pdftohtml_bin_location', self.pdftohtml_bin_location)
        IrConfigP.set_param('itis_report_subtotals.show_header_total_previous_page', self.show_header_total_previous_page)
        super(ResConfigSettings, self).set_values()
