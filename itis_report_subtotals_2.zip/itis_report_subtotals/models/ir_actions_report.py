# -*- coding: utf-8 -*-
# Part of IT IS AG. See LICENSE file for full copyright and licensing details.

import logging
from odoo import api, fields, models, _
from odoo.tools.misc import find_in_path
from odoo.exceptions import UserError

from bs4 import BeautifulSoup
from contextlib import closing
from odoo.tools.misc import find_in_path

import tempfile
import os
import subprocess
import sys
import re
import traceback

_logger = logging.getLogger(__name__)


XXpagenum = '‰:'


def _get_wkhtmltopdf_bin():
    return find_in_path('wkhtmltopdf')


class IrActionsReport(models.Model):
    """Inherits ir.actions.report to allow customizing the reports
    to have page totals for them."""
    _inherit = 'ir.actions.report'

    @api.model
    def _render_qweb_html(self, report_ref, docids, data=None):
        """This method generates and returns html version of a report."""
        # signatures/method checked
        # if last line is too long around 7-8 lines big and not added in the end of page then
        # then it goes to the next page and on the previous page there would be many blank lines
        if not data:
            data = {}

        from_pdf = self.env.context.get('from_pdf')

        data.setdefault('report_type', 'html')
        report = self._get_report(report_ref)
        data = self._get_rendering_context(report, docids, data)
        html_data = self._render_template(report.report_name, data)

        if 'total_by_page' not in data and from_pdf:  # and 1 == 2:
            _logger.info('creating BeautifulSoup')
            html_soup = BeautifulSoup(html_data, 'html.parser')
            _logger.info('BeautifulSoup created')
            env_context = dict(self.env.context)
            env_context.update({'from_pdf': False})
            self = self.with_context(env_context)

            tbdies = html_soup.findAll('tbody', {'class': 'sale_tbody'})
            div_id_total = html_soup.findAll('div', {'id': 'total'})

            marktextend = html_soup.new_tag('span')
            marktextend.string = str(XXpagenum + XXpagenum + XXpagenum)
            if len(div_id_total) > 0:
                div_id_total[0].insert_before(marktextend)

            if not tbdies:
                tbdies = html_soup.findAll('tbody')
            # make configurable
            if not tbdies:
                _logger.critical('Table tag for subtotal and footer/header customization not found. \
                    Report will be rendered normally.')
                return html_data, 'html'

            current_tr_index = 0
            updatedhtml = html_data
            cumulative_index = 0
            line_number = 0
            tr_indexes = []

            while(True):
                current_tr_index = updatedhtml.find(b'<tr')
                if current_tr_index == -1:
                    break
                current_tr_index = current_tr_index + 1
                cumulative_index = cumulative_index + current_tr_index
                tr_indexes.append(str(line_number) + ':' + str(cumulative_index))
                line_number = line_number + 1
                updatedhtml = html_data[cumulative_index:]

            html_data = html_soup.prettify().encode()
        print(html_data)
        return html_data, 'html'

    def get_html_from_template(self, rendering_context, field_boolean_flag):
        current_modelname = rendering_context['doc_model']
        email_template = self.env['mail.template'].search(
            [('model_id.model', '=', current_modelname), (field_boolean_flag, '=', True)], limit=1)
        body_html = ''
        if email_template:
            doc_ids = rendering_context['doc_ids']
            MailTemplates = self.env['mail.template']
            body_html = MailTemplates._render_template(  # .sudo(self.env.user)
                email_template.body_html,
                current_modelname,
                doc_ids)[doc_ids[0]]
            # fixlater: doc_ids[0] for multiple documents print
        return body_html

    def _get_pdftohtml_bin(self):
        return self.env['ir.config_parameter'].sudo().get_param('itis_report_subtotals.pdftohtml_bin_location', default='/usr/bin/pdftohtml')

    def delete_temporary_files(self, temporary_files):
        # Manual cleanup of the temporary files
        for temporary_file in temporary_files:
            try:
                os.unlink(temporary_file)
            except (OSError, IOError):
                _logger.error('Error when trying to remove file %s' % temporary_file)

    def convert_pdf_to_html(self, pdf_content):
        pdf_text_content = pdf_content
        temporary_files = []

        pdf_report_fd, pdf_report_path = tempfile.mkstemp(suffix='.pdf', prefix='report.itispdftmp.')
        temporary_files.append(pdf_report_path)
        pdf_file = os.fdopen(pdf_report_fd, 'wb')
        pdf_file.write(pdf_text_content)
        pdf_file.close()

        html_file_fd, html_file_path = tempfile.mkstemp(suffix='.html', prefix='report.itisconvhtml.tmp.')

        command_args = ['-i', '-s', '-noframes', pdf_report_path, html_file_path]
        # '-p', '-nomerge' # other options

        try:
            pdftohtml = [self._get_pdftohtml_bin()] + command_args
            # _logger.info(pdftohtml)
            process = subprocess.Popen(pdftohtml, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, err = process.communicate()

            if process.returncode not in [0, 1]:
                if process.returncode == -11:
                    message = _(
                        'pdftohtml failed (error code: %s). Memory limit too low or maximum file number of subprocess reached. Message : %s')
                else:
                    message = _('pdftohtml failed (error code: %s). Message: %s')
                raise UserError(message % (str(process.returncode), err[-1000:]))
            else:
                if err:
                    _logger.info('err %s' % (err))
        except Exception as exc:
            T, V, TB = sys.exc_info()
            error_traceback = '\n'.join(traceback.format_exception(T, V, TB))
            _logger.critical(str(exc))
            _logger.info(str(error_traceback))
            # raise UserError(str(exc))

        self.delete_temporary_files(temporary_files)

        return html_file_fd, html_file_path

    @api.model
    def _remove_currency_symbol(self, value):
        value = value.strip()
        negative = False
        # Careful that some countries use () for negative so replace it by - sign
        if value.startswith('(') and value.endswith(')'):
            value = value[1:-1]
            negative = True
        float_regex = re.compile(r'([-]?[0-9.,]+)')
        split_value = [g for g in float_regex.split(value) if g]
        if len(split_value) > 2:
            # This is probably not a float
            return False
        if len(split_value) == 1:
            if float_regex.search(split_value[0]) is not None:
                return split_value[0] if not negative else '-' + split_value[0]
            return False
        else:
            # String has been split in 2, locate which index contains the float and which does not
            currency_index = 0
            if float_regex.search(split_value[0]) is not None:
                currency_index = 1
            # Check that currency exists
            currency = self.env['res.currency'].search([('symbol', '=', split_value[currency_index].strip())])
            if len(currency):
                return split_value[(currency_index + 1) % 2] if not negative else '-' + split_value[(currency_index + 1) % 2]
            # Otherwise it is not a float with a currency symbol
            return False

    @api.model
    def _parse_float_from_data(self, data, index, name, options):
        thousand_separator = options.get('float_thousand_separator', ' ')
        decimal_separator = options.get('float_decimal_separator', '.')
        for line in data:
            line[index] = line[index].strip()
            if not line[index]:
                continue
            line[index] = line[index].replace(thousand_separator, '').replace(decimal_separator, '.')
            old_value = line[index]
            line[index] = self._remove_currency_symbol(line[index])

    def format_amount(self, amount, currency=None, lang=None):
        _logger.info("currency %s" % (currency))
        env = self.env
        if not currency:
            currency = self.env.user.company_id.currency_id
        fmt = "%.{0}f".format(currency.decimal_places)
        if not lang:
            lang = env['res.lang']._lang_get(env.context.get('lang') or 'de_DE')

        formatted_amount = lang.format(fmt, currency.round(amount), grouping=True, monetary=True)\
            .replace(r' ', u'\N{NO-BREAK SPACE}').replace(r'-', u'-\N{ZERO WIDTH NO-BREAK SPACE}')

        pre = post = u''
        if currency.position == 'before':
            pre = u'{symbol}\N{NO-BREAK SPACE}'.format(symbol=currency.symbol or '')
        else:
            post = u'\N{NO-BREAK SPACE}{symbol}'.format(symbol=currency.symbol or '')

        return u'{pre}{0}{post}'.format(formatted_amount, pre=pre, post=post)

    def _render_qweb_pdf(self, report_ref, res_ids=None, data=None):
        """
            Overriden method, calls super and then returns updated pdf content
        """
        env_context = dict(self.env.context)
        env_context.update({'from_pdf': True})
        self = self.with_context(env_context)
        pdf_content, filetype = super(IrActionsReport, self)._render_qweb_pdf(report_ref, res_ids, data)
        try:
            pass
            pdf_content, filetype = self.update_pdf_content(res_ids, data, pdf_content, filetype, report_ref)
        except Exception as exc:
            T, V, TB = sys.exc_info()
            error_traceback = '\n'.join(traceback.format_exception(T, V, TB))
            _logger.critical(str(exc))
            _logger.info(str(error_traceback))
        return pdf_content, filetype

    def update_pdf_content(self, res_ids, data, pdf_content, filetype, report_ref):
        report = self._get_report(report_ref)
        rendering_context = self._get_rendering_context(report, res_ids, data)
        field_boolean_footer = 'use_for_subtotal_footer'
        field_boolean_header = 'use_for_subtotal_header'

        body_html_footer = self.get_html_from_template(rendering_context, field_boolean_footer)
        body_html_header = self.get_html_from_template(rendering_context, field_boolean_header)
        context = dict(self.env.context)
        if body_html_footer:
            context['email_template_rendered_html_footer'] = body_html_footer
        if body_html_header:
            context['email_template_rendered_html_header'] = body_html_header
        self = self.with_context(context)

        _logger.info('Updating default pdf content: %s %s %s' % (res_ids, data, rendering_context))
        # if onoff reqiored switch is off return pdf_content
        # return pdf_content, filetype

        if data and 'total_by_page' in data:
            return pdf_content, filetype

        temporary_files = []

        html_file_fd, html_file_path = self.convert_pdf_to_html(pdf_content)
        temporary_files.append(html_file_path)

        total_by_page = {}
        total_page_amount = 0.0
        fl_amount = 0.0
        last_line_number_bs = None
        cpage_i = 0
        page_total_csv = ''
        previous_dollar_alone = False
        exit_on_subtotal = True
        last_bs_text = ''

        main_company = self.env.ref('base.main_company')
        document_lang = main_company.partner_id.lang
        try:
            doc_partner_lang = rendering_context.get('docs')[0].partner_id.lang
            if doc_partner_lang:
                document_lang = doc_partner_lang
        except:
            pass
        if not document_lang:
            raise UserError("Please set language on %s company partner" % (main_company.name))

        doc_reslang = self.env['res.lang'].search([('code', '=', document_lang)])
        thousand_separator, decimal_point = doc_reslang.thousands_sep, doc_reslang.decimal_point

        doc_currency_id = main_company.currency_id
        try:
            doc_cur = rendering_context.get('docs')[0].currency_id
            if doc_cur:
                doc_currency_id = doc_cur
        except:
            pass
        if not doc_currency_id:
            raise UserError("Please set currency on %s company partner" % (doc_currency_id.name))

        currency_symbol = doc_currency_id.symbol
        currency_position = doc_currency_id.position
        with open(html_file_path, 'r', errors='ignore', encoding="utf-8") as html_doc:
            # encoding="ISO-8859-1"
            html_content = html_doc.read()
            lines = html_content.split('\n')
            # _logger.info('lines %s' % (lines))
            # _logger.info('lines %s'%(html_content))
            for line in lines:
                bs_line = BeautifulSoup(line, 'html.parser')
                bs_text = bs_line.get_text().replace(u'\xa0', u' ')
                # _logger.info('bs_text, bs_line %s %s' % (bs_text, bs_line))

                amount = None
                fl_amount = 0
                generic_currency_cond_b4 = currency_position == 'before' and bs_text.startswith(currency_symbol)
                generic_currency_cond_a4 = currency_position == 'after' and bs_text.endswith(currency_symbol)

                try:
                    if exit_on_subtotal and bs_text.index(str(XXpagenum + XXpagenum + XXpagenum)) != -1:
                        break
                except:
                    pass
                try:
                    subtotal_text = bs_text[0:bs_text.index(currency_symbol)].strip()
                    if ' ' in subtotal_text:
                        subtotal_text = subtotal_text[0:subtotal_text.index(' ')]
                    if subtotal_text in ['Subtotal', 'Zwischensumme']:
                        last_bs_text = bs_text.strip()
                        continue
                except:
                    pass

                bs_text = bs_text.strip()

                try:
                    if currency_symbol in bs_text:
                        endoflines = False
                        nbs = str(bs_line)
                        nbs = nbs[nbs.index('left:'):]
                        nbs = nbs[:nbs.index('px;')]
                        nbs = nbs[nbs.index(':') + 1:]
                        if int(nbs) > 700:
                            endoflines = True
                        currency_symbol_index = bs_text.index(currency_symbol)
                        if currency_position == 'before' and endoflines:
                            bs_text = bs_text[currency_symbol_index:]
                        if currency_position == 'after' and endoflines:
                            bs_text = bs_text[:currency_symbol_index + 1]
                except:
                    pass
                if generic_currency_cond_b4 or generic_currency_cond_a4:
                    cuse_symbol = currency_symbol
                startdollar = bs_text.startswith('$')
                endeuro = bs_text.endswith('€')
                if not startdollar and not endeuro and not previous_dollar_alone and not generic_currency_cond_b4 and not generic_currency_cond_a4:
                    if currency_symbol in bs_text:
                        bs_text = bs_text[bs_text.index(currency_symbol):]
                        startdollar = bs_text.startswith('$')
                        endeuro = bs_text.endswith('€')
                if startdollar:
                    cuse_symbol = '$'
                if endeuro:
                    cuse_symbol = '€'
                if startdollar or previous_dollar_alone or generic_currency_cond_b4:
                    amount = bs_text
                    if not previous_dollar_alone:
                        amount = bs_text[1:]
                    # amount = amount.replace(',', '')
                    amount = amount.replace(thousand_separator, '')
                    amount = amount.replace(decimal_point, '.')
                    previous_dollar_alone = False
                    if previous_dollar_alone:
                        _logger.info("last was %s" % (amount))
                    try:
                        fl_amount = float(amount)
                        total_page_amount = total_page_amount + fl_amount
                        _logger.critical("added total_page_amount %s fl_amount %s" % (total_page_amount, fl_amount))
                    except:
                        _logger.info('amount %s bs_text %s' % (amount, bs_text))
                        if bs_text.strip() == cuse_symbol:
                            previous_dollar_alone = True
                elif endeuro or generic_currency_cond_a4:

                    last_second_space = 0
                    try:
                        euro_index = bs_text.index(' ' + cuse_symbol)
                    except:
                        if bs_text.strip() == cuse_symbol:
                            euro_index = len(last_bs_text)
                            bs_text = last_bs_text.strip()
                    try:
                        last_second_space = bs_text[0:euro_index].rindex(' ')
                    except:
                        pass
                    amount = bs_text[last_second_space:euro_index]
                    # amount = amount.replace('.', '')
                    # amount = amount.replace(',', '.')
                    amount = amount.replace(thousand_separator, '')
                    amount = amount.replace(decimal_point, '.')
                    try:
                        fl_amount = float(amount)
                    except:
                        pass
                    total_page_amount = total_page_amount + fl_amount
                    _logger.critical("added total_page_amount %s fl_amount %s" % (total_page_amount, fl_amount))

                if XXpagenum in bs_text:
                    last_line_number_bs = bs_text
                # _logger.info("bs_line.div %s %s %s" % (bs_line.div, last_line_number_bs, bs_text))
                if bs_line.div:  # and last_line_number_bs:
                    # _logger.info("cpage_i %s" % (cpage_i))
                    if cpage_i != 0:  # and total_page_amount != 0.0:
                        str_total_amount = self.format_amount(total_page_amount, doc_currency_id, doc_reslang)
                        page_total_csv = page_total_csv + str(str_total_amount) + ';'
                    cpage_i = cpage_i + 1
                    # _logger.critical('Report Subtotals: New Page %s' % (total_page_amount))
                last_bs_text = bs_text.strip()

        if exit_on_subtotal:
            str_total_amount = self.format_amount(total_page_amount, doc_currency_id, doc_reslang)
            page_total_csv = page_total_csv + str(str_total_amount) + ';'

        if not data:
            data = {}
        data['total_by_page'] = "total_by_page"
        _logger.info('Page Totals: %s' % (page_total_csv))
        # subtotal in last page is not required
        # last page subtotal also adds all the euro/dollar subtotal values
        context = dict(self.env.context)
        # if page_total_csv.index(';') == page_total_csv.rindex(';'):
        #     page_total_csv = '0.0;'
        context['page_total_csv'] = page_total_csv
        context['cpage_i'] = cpage_i
        pdf_content, filetype = super(IrActionsReport, self.with_context(context))._render_qweb_pdf(report_ref, res_ids, data)

        self.delete_temporary_files(temporary_files)
        return pdf_content, filetype

    @api.model
    def _run_wkhtmltopdf(
            self,
            bodies,
            report_ref=False,
            header=None,
            footer=None,
            landscape=False,
            specific_paperformat_args=None,
            set_viewport_size=False):
        paperformat_id = self._get_report(report_ref).get_paperformat() if report_ref else self.get_paperformat()
        # Build the base command args for wkhtmltopdf bin
        command_args = self._build_wkhtmltopdf_args(
            paperformat_id,
            landscape,
            specific_paperformat_args=specific_paperformat_args,
            set_viewport_size=set_viewport_size)

        files_command_args = []

        # ###############################custom start
        temporary_files = []

        def add_email_template(html_body, email_template_rendered_html):
            try:
                body = '</body>'
                html_body_index = html_body.index(body)
                html_body = html_body[0:html_body_index] + email_template_rendered_html + \
                    html_body[html_body_index:]
            except Exception as exc:
                T, V, TB = sys.exc_info()
                error_traceback = '\n'.join(traceback.format_exception(T, V, TB))
                _logger.critical(str(exc))
                _logger.info(str(error_traceback))
                # raise UserError()

            return html_body

        context = dict(self.env.context)
        email_template_rendered_html = None
        email_template_rendered_header_html = None
        page_total_csv = None
        cpage_i = 0
        if 'email_template_rendered_html_footer' in context:
            email_template_rendered_html = context.pop('email_template_rendered_html_footer')

        if 'email_template_rendered_html_header' in context:
            email_template_rendered_header_html = context.pop('email_template_rendered_html_header')

        if 'page_total_csv' in context:
            page_total_csv = context.pop('page_total_csv')
        if 'cpage_i' in context:
            cpage_i = context.pop('cpage_i')

        def add_page_totals(body_html, permanent_placeholder, header=False, footer=False):
            try:
                if footer:
                    itis_footer = ' name="itis_footer">'

                    if itis_footer in body_html and email_template_rendered_html:
                        div_page_begin_index = body_html.index('<div class="text-muted mt-2 mb-2">')
                        intermed_index = body_html[div_page_begin_index:].index('class="topage"')
                        intermed_index = div_page_begin_index + intermed_index
                        firstspan_end_index = body_html[intermed_index:].index('</span>') + 1
                        firstspan_end_index = firstspan_end_index + intermed_index
                        finalspan_end_index = body_html[firstspan_end_index:].index('</div>') + len('</div>') + 1
                        finalspan_end_index = finalspan_end_index + firstspan_end_index
                        body_html = body_html[0:div_page_begin_index] + body_html[finalspan_end_index:]

                        # itisfooter_begin_index = body_html.index(b'name="itis_footer"')
                        # p_index = body_html[itisfooter_begin_index:].index(b'<table')
                        # p_index = itisfooter_begin_index + p_index
                        # body_html = body_html[0:p_index] + b'<span>' + body_html[p_index + len(b'<table'):]

                        # itisfooter_begin_index = body_html.index(b'name="itis_footer"')
                        # pend_index = body_html[itisfooter_begin_index:].index(b'</table>')
                        # pend_index = itisfooter_begin_index + pend_index
                        # body_html = body_html[0:pend_index] + b'</span>' + body_html[pend_index + len(b'</table>'):]

                    index_d = body_html.index(permanent_placeholder) + len(permanent_placeholder)
                    newindex_touse = body_html[index_d:].index('>') + 1

                    if itis_footer in body_html:
                        newindex_touse = body_html[index_d:].index(itis_footer) + len(itis_footer) + 1

                    new_index = body_html[index_d + newindex_touse:].index('<div')
                    final_index = index_d + newindex_touse + new_index
                    # final_index = body_html.index(b'<div class="text-center" style="border-top:')
                    # new_subtotal = '<div class="page_subtotalx">Subtotal</div>'#id="page_subtotal" pull-right
                    page_subtotal_string = _('Page Subtotal: ')
                    new_subtotal = '<span class="page_subtotalx_parent" style="overflow:hidden"><span class="pull-right">' + \
                        '' + '<b><span class="page_subtotalx" style="white-space:nowrap">' + \
                        page_subtotal_string + '</span></b></span></span><br/>'  # <br/>

                    def remove_existing_page_numbers(body_html):
                        div_start = '<div'
                        div_end = '</div>'
                        page_index = body_html.index('Page:')
                        print(page_index)
                        pagediv_index = body_html[0:page_index].rindex(div_start)
                        print(pagediv_index)
                        div_close_index = page_index + body_html[page_index:].index(div_end) + len(div_end)
                        print(div_close_index)
                        print(body_html[pagediv_index: div_close_index])
                        body_html = body_html[0:pagediv_index] + body_html[div_close_index:]
                        return body_html

                    if itis_footer not in body_html:
                        new_subtotal = new_subtotal + '<br/>'
                        if email_template_rendered_html:
                            body_html = remove_existing_page_numbers(body_html)
                    # _logger.info("%s" % (body_html))
                    body_html = body_html[0:final_index] + new_subtotal + body_html[final_index:]

                display_total_till_page = cpage_i

                def replace_text_html(body_html, replace_text, replace_value):
                    replace_text_index = body_html.index(replace_text)
                    _logger.info("replace_text_index %s" % (replace_text_index))
                    return body_html[0:replace_text_index] + \
                        replace_value + body_html[replace_text_index + len(replace_text):]

                replace_value = "var page_totals = '" + page_total_csv + "';"
                replace_text = "var page_totals = 'XXX';"
                body_html = replace_text_html(body_html, replace_text, replace_value)

                show_header_total_previous_page = self.env['ir.config_parameter'].sudo().get_param(
                    'itis_report_subtotals.show_header_total_previous_page', default=False)
                if show_header_total_previous_page:
                    replace_value = "var header_totals_index = 2;"
                    replace_text = "var header_totals_index = 1;"
                    body_html = replace_text_html(body_html, replace_text, replace_value)

                replace_value_2 = "var display_total_till_page = " + str(display_total_till_page) + ";"
                replace_text_2 = "var display_total_till_page = 'XXX';"
                _logger.info(str(replace_value_2))
                _logger.info(str(replace_value))
                body_html = replace_text_html(body_html, replace_text_2, replace_value_2)
            except Exception as exc:
                T, V, TB = sys.exc_info()
                error_traceback = '\n'.join(traceback.format_exception(T, V, TB))
                _logger.critical(str(exc))
                _logger.info(str(error_traceback))
            # _logger.info("body_html \n%s" % (body_html))
            return body_html
        # ###############################custom end

        if header:
            head_file_fd, head_file_path = tempfile.mkstemp(suffix='.html', prefix='report.header.tmp.')
            temporary_files.append(head_file_path)

            with closing(os.fdopen(head_file_fd, 'wb')) as head_file:
                # ###############################custom start
                # test div class company_address or div name company_address - done
                # test with different report styles, - done
                # test with dollars or other currency
                # mro one print of so, sale_tbody, other po reports
                # test translations, update translation file - done
                # delete temp files during generation - done
                # generalize and add try catch blocks - done
                # check and remove _logger - done
                # headers to show previous page total ? - done

                if email_template_rendered_header_html:
                    try:
                        header_soup = BeautifulSoup(header, 'html.parser')
                        div_company_address = header_soup.findAll('div', {'class': 'col-12 text-right'})
                        if not div_company_address:
                            div_company_address = header_soup.findAll('div', {'name': 'company_address'})
                        new_div_classes = []
                        if not div_company_address:
                            div_company_address = header_soup.findAll('img', {'alt': 'Logo'})
                            if not div_company_address:
                                div_company_address = header_soup.findAll('img', {'class': 'float-left'})

                            new_div_classes = ['pull-right']
                        else:
                            new_div_classes = ['pull-right', 'col-6']

                        new_div = header_soup.new_tag('div')
                        new_div['class'] = new_div.get('class', []) + new_div_classes
                        new_div.append(BeautifulSoup(email_template_rendered_header_html, 'html.parser'))
                        div_company_address[0].insert_after(new_div)
                        header = header_soup.prettify()
                    except Exception as exc:
                        T, V, TB = sys.exc_info()
                        error_traceback = '\n'.join(traceback.format_exception(T, V, TB))
                        _logger.critical(str(exc))
                        _logger.info(str(error_traceback))
                    _logger.info(str(header))

                if page_total_csv:
                    permanent_placeholder = 'id="minimal_layout_report_headers">'
                    header = add_page_totals(header, permanent_placeholder, header=True, footer=False)
                    _logger.info('page_totals added in header.')

                # _logger.info('header %s'%(header))
                # ###############################custom end
                head_file.write(header.encode())
            temporary_files.append(head_file_path)
            files_command_args.extend(['--header-html', head_file_path])

        if footer:
            foot_file_fd, foot_file_path = tempfile.mkstemp(suffix='.html', prefix='report.footer.tmp.')
            temporary_files.append(foot_file_path)
            with closing(os.fdopen(foot_file_fd, 'wb')) as foot_file:
                # ###############################custom start
                # date,document_name,page x of x
                if page_total_csv:
                    permanent_placeholder = 'id="minimal_layout_report_footers">'
                    footer = add_page_totals(footer, permanent_placeholder, header=False, footer=True)
                    # _logger.info('footer %s'%(footer))
                    _logger.info('page_totals added in footer.')
                if email_template_rendered_html:
                    try:
                        if self.get_paperformat().id == self.env.ref('l10n_de.paperformat_euro_din').id:
                            extra_margin_div = '<div style="margin-left:96px;margin-right:86px;">'
                            email_template_rendered_html = extra_margin_div + email_template_rendered_html + '</div>'
                    except:
                        pass
                    footer = add_email_template(footer, email_template_rendered_html)
                # ###############################custom end
                foot_file.write(footer.encode())
            files_command_args.extend(['--footer-html', foot_file_path])

        # files_command_args.extend(['--debug-javascript'])

        paths = []
        for i, body in enumerate(bodies):
            prefix = '%s%d.' % ('report.body.tmp.', i)
            body_file_fd, body_file_path = tempfile.mkstemp(suffix='.html', prefix=prefix)
            with closing(os.fdopen(body_file_fd, 'wb')) as body_file:
                body_file.write(body.encode())
            paths.append(body_file_path)
            temporary_files.append(body_file_path)

        pdf_report_fd, pdf_report_path = tempfile.mkstemp(suffix='.pdf', prefix='report.tmp.')
        os.close(pdf_report_fd)
        temporary_files.append(pdf_report_path)

        try:
            wkhtmltopdf = [_get_wkhtmltopdf_bin()] + command_args + files_command_args + paths + [pdf_report_path]
            process = subprocess.Popen(wkhtmltopdf, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, err = process.communicate()

            if process.returncode not in [0, 1]:
                if process.returncode == -11:
                    message = _(
                        'Wkhtmltopdf failed (error code: %s). Memory limit too low or maximum file number of subprocess reached. Message : %s')
                else:
                    message = _('Wkhtmltopdf failed (error code: %s). Message: %s')
                raise UserError(message % (str(process.returncode), err[-1000:]))
        except:
            raise

        with open(pdf_report_path, 'rb') as pdf_document:
            pdf_content = pdf_document.read()

        # Manual cleanup of the temporary files
        for temporary_file in temporary_files:
            try:
                os.unlink(temporary_file)
            except (OSError, IOError):
                _logger.error('Error when trying to remove file %s' % temporary_file)

        return pdf_content
