# -*- coding: utf-8 -*-
# Part of IT IS AG. See LICENSE file for full copyright and licensing details.

import logging
from odoo import api, fields, models, _

_logger = logging.getLogger(__name__)


class MailTemplate(models.Model):
    _inherit = 'mail.template'

    use_for_subtotal_header = fields.Boolean('Custom Header & Subtotals')
    use_for_subtotal_footer = fields.Boolean('Custom Footer & Subtotals')
