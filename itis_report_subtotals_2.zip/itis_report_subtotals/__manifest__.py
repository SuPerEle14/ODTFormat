# -*- coding: utf-8 -*-
# Part of IT IS AG. See LICENSE file for full copyright and licensing details.

# Font Awesome 4.7.0 by @davegandy - http://fontawesome.io - @fontawesome
# License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)

{
    'name': "IT IS Report Subtotals and Custom header/footers",
    'version': "1.3",
    'category': 'Report',
    'sequence': 25,

    'summary': """
        Page-wise Subtotals on PDF Reports and Customizable Report header/footers.
    """,

    'description': """
        This module adds page-wise subtotals on PDF Reports,
        PDF Report header/footers can be added and designed separately for each kind of report,

        Email Templates for header and footer can be created per model,
        On Email Template, Mark 'Use for Header' and 'Use for Footer' for using the email template design on report.
    """,
    'author': "IT IS AG",
    'website': "https://www.itis.de",
    'depends': [
        'sale_management',
    ],
    'data': [
        'views/custom_minimal_layout.xml',
        'views/res_config_settings.xml',
        'data/mail_template_header_footer.xml',
        'views/mail_template_view.xml',
    ],
    'external_dependencies': {
        'python': ['bs4', ],
        'bin': ['pdftohtml'],
    },
    'demo': [],
    'application': True,
    'post_init_hook': '_configure_paperformat_bottom_margins',
}
