===============================================================================
Change Log (itis_report_subtotals)
===============================================================================

[1.3 : 17 December 2021]
	
	- Add minor enhancements

[1.2 : 08 November 2021]
	
	- Add font-awesome license in __manifest__ file


[1.1 : 06 July 2021]
	
	- Internal OPS and other enhancements

[1.0 : 25 Jan 2021]
	
	- Module migrated to v14
