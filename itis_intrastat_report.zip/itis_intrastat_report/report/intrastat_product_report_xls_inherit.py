# -*- coding: utf-8 -*-
# Part of IT IS AG. See LICENSE file for full copyright and licensing details.

from odoo import models
from odoo.addons.report_xlsx_helper.report.report_xlsx_format import (
    FORMATS,
    XLS_HEADERS,
)


class IntrastatProductDeclarationXlsx(models.AbstractModel):
    _inherit = 'report.intrastat_product.product_declaration_xls'

    def _get_template(self, declaration):

        template = {
            'invoice_type': {
                'header': {
                    'type': 'string',
                    'value': self._('Invoice Type'),
                },
                'line': {
                    'type': 'string',
                    'value': self._render("'E' if line.invoice_id.journal_id.type == 'sale' else 'V'"),
                },
                'width': 3,
            },
            'invoice_date': {
                'header': {
                    'type': 'string',
                    'value': self._('Month'),
                },
                'line': {
                    'type': 'string',
                    'value': self._render("line.parent_id.month"),
                },
                'width': 3,
            },
            'bussiness_type': {
                'header': {
                    'type': 'string',
                    'value': self._('Business Type'),
                },
                'line': {
                    'type': 'string',
                    'value': self._render("line.invoice_id.intrastat_transaction_id.code or ''"),
                },
                'width': 3,
            },
            'transport_mode': {
                'header': {
                    'type': 'string',
                    'value': self._('Transport Mode'),
                },
                'line': {
                    'type': 'string',
                    'value': self._render("line.transport_id.code or ''"),
                },
                'width': 2,
            },
            'src_dest_country1': {
                'header': {
                    'type': 'string',
                    'value': self._('Shipping Country'),
                },
                'line': {
                    'type': 'string',
                    'value': self._render(
                        "line.src_dest_country_id.code if line.invoice_id.journal_id.type == 'sale' else ''"),
                },
                'width': 3,
            },
            'src_dest_country2': {
                'header': {
                    'type': 'string',
                    'value': self._('Shipping Country if arrivals'),
                },
                'line': {
                    'type': 'string',
                    'value': self._render(
                        "line.src_dest_country_id.code if line.invoice_id.journal_id.type != 'sale' else ''"),
                },
                'width': 3,
            },
            'src_dest_country3': {
                'header': {
                    'type': 'string',
                    'value': self._('Destination Country'),
                },
                'line': {
                    'type': 'string',
                    'value': self._render(
                        "line.invoice_id.src_dest_country_id.code or ''"),
                },
                'width': 3,
            },
            'dest_origin': {
                'header': {
                    'type': 'string',
                    'value': self._('Destination Region'),
                },
                'line': {
                    'type': 'string',
                    'value': self._render(
                        "line.invoice_id.src_dest_region_id.code or ''"),
                },
                'width': 3,
            },
            'region': {
                'header': {
                    'type': 'string',
                    'value': self._('Origin Region'),
                },
                'line': {
                    'type': 'string',
                    'value': self._render("line.region_id.name or ''"),
                },
                'width': 3,
            },
            'region_country': {
                'header': {
                    'type': 'string',
                    'value': self._('Origin Country'),
                },
                'line': {
                    'type': 'string',
                    'value': self._render("line.region_id.country_id.code or ''"),
                },
                'width': 3,
            },
            'hs_code': {
                'header': {
                    'type': 'string',
                    'value': self._('HS Code'),
                },
                'line': {
                    'type': 'string',
                    'value': self._render(
                        "line.hs_code_id.local_code or ''"),
                },
                'width': 14,
            },
            'weight': {
                'header': {
                    'type': 'string',
                    'value': self._('Weight'),
                },
                'line': {
                    'type': 'number',
                    'value': self._render("line.weight or 0"),
                    'format': FORMATS["format_tcell_amount_right"],
                },
                'width': 14,
            },
            'unit_of_measure': {
                'header': {
                    'type': 'string',
                    'value': self._('Unit of Measure'),
                },
                'line': {
                    'type': 'number',
                    'value': self._render("line.suppl_unit_qty or 0"),
                    'format': FORMATS["format_tcell_amount_right"],
                },
                'width': 14,
            },
            'invoice_value': {
                'header': {
                    'type': 'string',
                    'value': self._('Invoice Value'),
                },
                'line': {
                    'type': 'number',
                    'value': self._render("line.invoice_id.amount_total or 0.0"),
                    'format': FORMATS["format_tcell_amount_right"],
                },
                'width': 14,
            },
            'fiscal_value': {
                'header': {
                    'type': 'string',
                    'value': self._('Fiscal Value'),
                },
                'line': {
                    'type': 'number',
                    'value': self._render("line.amount_company_currency or 0.0"),
                    'format': FORMATS["format_tcell_amount_right"],
                },
                'width': 14,
            },
            'vat': {
                'header': {
                    'type': 'string',
                    'value': self._('VAT'),
                },
                'line': {
                    'type': 'string',
                    'value': self._render(
                        "line.invoice_id.partner_id.vat or ''"),
                },
                'width': 16,
            },

            'product': {
                'header': {
                    'type': 'string',
                    'value': self._('Product'),
                },
                'line': {
                    'value': self._render(
                        "line.product_id and line.product_id.name or ''"),
                },
                'width': 36,
            },
            
            'accessory_cost': {
                'header': {
                    'type': 'string',
                    'value': self._('Accessory Costs'),
                    'format': FORMATS["format_theader_yellow_right"],
                },
                'line': {
                    'type': 'number',
                    'value': self._render(
                        "line.amount_accessory_cost_company_currency"),
                    'format': FORMATS["format_tcell_amount_right"],
                },
                'width': 18,
            },
            'transaction': {
                'header': {
                    'type': 'string',
                    'value': self._('Intrastat Transaction'),
                },
                'line': {
                    'value': self._render(
                        "line.transaction_id.display_name"),
                },
                'width': 36,
            },
            
            'suppl_unit_qty': {
                'header': {
                    'type': 'string',
                    'value': self._('Suppl. Unit Qty'),
                    'format': FORMATS["format_theader_yellow_right"],
                },
                'line': {
                    # we don't specify a type here and rely on the
                    # report_xlsx_helper type detection to use
                    # write_string when suppl_unit_qty is zero
                    'value': self._render(
                        "line.suppl_unit_qty or ''"),
                    'format': FORMATS["format_tcell_amount_right"],
                },
                'width': 18,
            },
            'suppl_unit': {
                'header': {
                    'type': 'string',
                    'value': self._('Suppl. Unit'),
                },
                'line': {
                    'value': self._render(
                        "line.intrastat_unit_id.name or ''"),
                },
                'width': 14,
            },
            'incoterm': {
                'header': {
                    'type': 'string',
                    'value': self._('Incoterm'),
                },
                'line': {
                    'value': self._render("line.incoterm_id.name or ''"),
                },
                'width': 14,
            },
            'invoice': {
                'header': {
                    'type': 'string',
                    'value': self._('Invoice'),
                },
                'line': {
                    'value': self._render("line.invoice_id.number"),
                },
                'width': 18,
            },

            # Add Addtional values for GSS Project
            'quantity': {
                'header': {
                    'type': 'string',
                    'value': self._('Quantity'),
                },
                'line': {
                    'value': self._render("line.invoice_line_id.quantity"),
                },
                'width': 18,
            },
        }
        template.update(declaration._xls_template())

        return template

    # Overrider the method due to both sheet we need in single file
    def _get_ws_params(self, wb, data, declaration):
        template = self._get_template(declaration)

        title_short = self._get_title(declaration, 'computation',
                                      title_format='short')
        sheet_name = title_short[:31].replace('/', '-')

        computation_params = {
            'ws_name': sheet_name,
            'generate_ws_method': '_intrastat_computation_report',
            'title': self._get_title(declaration, 'computation', title_format='normal'),
            'wanted_list': declaration._xls_computation_line_fields(),
            'col_specs': template,
        }

        # title_short = self._get_title(declaration, 'declaration',
        #                               title_format='short')
        # sheet_name = title_short[:31].replace('/', '-')
        # declaration_params = {
        #     'ws_name': sheet_name+'-Declaration-Lines',
        #     'generate_ws_method': '_intrastat_declaration_report',
        #     'title': self._get_title(declaration, 'declaration', title_format='normal'),
        #     'wanted_list': declaration._xls_declaration_line_fields(),
        #     'col_specs': template,
        # }
        return [computation_params]#, declaration_params]

    def _intrastat_computation_report(self, workbook, ws, ws_params, data, declaration):

        ws.set_landscape()
        ws.fit_to_pages(1, 0)
        ws.set_header(XLS_HEADERS["xls_headers"]["standard"])
        ws.set_footer(XLS_HEADERS["xls_footers"]["standard"])

        self._set_column_width(ws, ws_params)

        row_pos = 0
        row_pos = self._report_title(ws, row_pos, ws_params, data, declaration)

        computation_lines = declaration.computation_line_ids

        if not computation_lines:
            return self._empty_report(
                ws, row_pos, ws_params, data, declaration, 'computation')

        row_pos = self._write_line(
            ws, row_pos, ws_params, col_specs_section='header',
            default_format=FORMATS["format_theader_yellow_left"])

        ws.freeze_panes(row_pos, 0)

        for line in computation_lines:
            row_pos = self._write_line(
                ws, row_pos, ws_params, col_specs_section='line',
                render_space={'line': line},
                default_format=FORMATS["format_tcell_left"])
