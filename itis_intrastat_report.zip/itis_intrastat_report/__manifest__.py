# -*- coding: utf-8 -*-
# Part of IT IS AG. See LICENSE file for full copyright and licensing details.

{
    'name': 'IT IS Intrastat Report',
    'version': '1.0',
    'category': 'Accounting & Finance',
    'sequence': 1,
    'summary': 'Intrastat Reports',
    'version': '16.0.1.0.0',
    'description': """
This modules provides an Intrastat Export for Germany with required fields and values.
    """,
    'author': "IT IS AG",
    'website': "http://www.itis.de",
    'depends': ['intrastat_product'],
    'data': [
        'views/intrastat_product_declaration.xml',
    ],
    'demo': [

    ],
    'qweb': [
    ],
    'external_dependencies': {
        'python': ['python-stdnum>=1.16'],
    },
    'application': False,
    'installable': True,
    'auto_install': False,
}
