# -*- coding: utf-8 -*-
# Part of IT IS AG. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _


class IntrastatProductDeclaration(models.Model):
    _inherit = 'intrastat.product.declaration'

    # Overrider the above methods for GSS Project
    @api.model
    def _xls_computation_line_fields(self):
        """ Update list in custom module to add/drop columns or change order """
        return [
            'invoice_type', 'invoice_date', 'bussiness_type', 'transport_mode', 
            'src_dest_country1', 'src_dest_country2', 'src_dest_country3', 
            'dest_origin', 'region', 'region_country', 'hs_code', 'weight', 
            'unit_of_measure', 'invoice_value', 'fiscal_value', 'vat',
        ]

    @api.model
    def _xls_declaration_line_fields(self):
        """ Update list in custom module to add/drop columns or change order """
        return [
            'hs_code', 'src_dest_country', 'amount_company_currency',
        ]
